#ifndef _BUSYBIN_BRASS_H_
#define _BUSYBIN_BRASS_H_

#include "Material.h"

namespace busybin
{
  /**
   * A basic Brass material.
   */
  class Brass : public Material
  {
  public:
    Brass();
  };
}

#endif
