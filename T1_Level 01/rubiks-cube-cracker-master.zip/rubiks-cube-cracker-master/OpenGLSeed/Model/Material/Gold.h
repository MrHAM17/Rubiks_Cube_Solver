#ifndef _BUSYBIN_GOLD_H_
#define _BUSYBIN_GOLD_H_

#include "Material.h"

namespace busybin
{
  /**
   * A basic Gold material.
   */
  class Gold : public Material
  {
  public:
    Gold();
  };
}

#endif
