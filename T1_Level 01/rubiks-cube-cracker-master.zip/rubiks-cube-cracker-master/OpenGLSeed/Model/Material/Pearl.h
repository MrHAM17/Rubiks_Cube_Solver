#ifndef _BUSYBIN_PEARL_H
#define _BUSYBIN_PEARL_H

#include "Material.h"

namespace busybin
{
  /**
   * A shiny Pearly material.
   */
  class Pearl : public Material
  {
  public:
    Pearl();
  };
}

#endif
