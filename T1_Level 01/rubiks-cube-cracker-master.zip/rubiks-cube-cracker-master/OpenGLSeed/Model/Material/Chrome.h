#ifndef _BUSYBIN_CHROME_H
#define _BUSYBIN_CHROME_H

#include "Material.h"

namespace busybin
{
  /**
   * A shiny chrome material.
   */
  class Chrome : public Material
  {
  public:
    Chrome();
  };
}

#endif
